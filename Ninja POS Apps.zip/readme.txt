How to use ninja pos apps

+ This pos apps work with windows OS 32/84 bit, so make sure your windows is 32/84 bit
+ Install ms accsess or accsess run time for using this apps
+ Download Ninja Pos Apps
+ Extract on your folder project
+ Double click on ninja pos apps file
+ Then you need click open on ms accsess
+ Login with username : admin and password : admin
+ Now you can accsses and work with ninja pos apps.

First use :
+ need to create a databased 
+ User for create and register user
+ Password for change password
+ Accsess for create user accses account like admin or cashier
+ Supplier for register your supplier
+ Group for create new group products, like food or drink and more
+ Purchase for create new pruchase transaction to your supplier
+ Purchase Return for create return purchase transaction
+ Point of sale for create new POS cashier transaction and automaticly print out.
+ POS return for return cashier sale transaction
+ Report for chek all report details like inventori, sale, purchase and more.
+ Bonus Kalkulator short cut and notepad shortcut
+ Log Off for out and change user
+ Shutdown for close ninja pos apps .

Free and open source code project present by https://www.hockeycomputindo.com
made with love by https://mesinkasironline.web.app - https://mesinkasir.github.io


Donation

make a contribution by sharing our application with the world through your social media or voluntary donations to our account so we can give the best for you again.

Donate Now using moneygram or western union send money to we local bank account.

BANK CENTRAL ASIA
ACCOUNT NO : 0181884109
ACCOUNT NAME : SUCI CHANIFAH
IBAN/SWIFT CODE : CENAIDJA